import { N, _ } from "../chunks/2.BuoS0npz.js";
export {
  N as component,
  _ as universal
};
